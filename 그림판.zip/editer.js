var canvas;
var clearEl = $('clear-canvas');
var target;
$(function () {
    canvas = window._canvas = new fabric.Canvas('c');
    canvas.isDrawingMode= 1;
    canvas.freeDrawingBrush.width = 10;
    canvas.renderAll();

    document.getElementById('pick').addEventListener('click', function (e) {
        target = e.target.id;
        $('#choose_color').val(target);
        console.log(target);
        canvas.freeDrawingBrush.color = target;
    });
    document.getElementById('clear-canvas').addEventListener('click', function (e) {
        canvas.clear()
        console.log("전체 지우기 실행");
    });
    $('#choose_color').click(function(){
        $('#choose_color').val("");
    })
    $('#apply_color').click(function(){
        target = $('#choose_color').val();
        console.log(target);
        canvas.freeDrawingBrush.color = target;
    })
});